 

 Certain portions of this software are based on source code from OpenJDK
(http://openjdk.java.net/)  and  licensed  under  the GNU General Public
License  version  2  (GPLv2)  with   the  Classpath  Exception  (http://
openjdk.java.net/legal/gplv2+ce.html).  For a period of three years from
the date  of your receipt  of  this  software,  Azul  will  provide upon
request, a complete  machine readable  copy of the  source code for such
portions  based  on  OpenJDK on a medium  customarily used  for software
interchange for a charge no more  than the cost of physically performing
source distribution.


  Please email azul_openjdk@azul.com for further information.

  Include this version code in your email:
  Zulu 8.28.0.1 04ade267f927

